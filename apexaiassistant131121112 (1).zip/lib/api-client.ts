/**
 * Centralized API Client
 * 
 * Provides a robust HTTP client with:
 * - Automatic retry with exponential backoff
 * - Request timeouts with AbortController
 * - Normalized error handling
 * - Type-safe responses with discriminated unions
 */

import { logger } from './logger'

// API Error types
export interface ApiError {
  code: string
  message: string
  status?: number
  details?: unknown
}

// Discriminated union response type
export type ApiResponse<T> = 
  | { success: true; data: T; timestamp: string }
  | { success: false; error: ApiError; timestamp: string }

// API Client configuration
export interface ApiClientConfig {
  baseUrl?: string
  timeout?: number
  retries?: number
  retryDelay?: number
}

/**
 * Normalize errors to consistent ApiError format
 */
function normalizeError(error: unknown): ApiError {
  // Network errors
  if (error instanceof TypeError) {
    return {
      code: 'NETWORK_ERROR',
      message: 'Network connection failed. Please check your internet connection.',
    }
  }

  // Timeout errors
  if (error instanceof Error && error.name === 'AbortError') {
    return {
      code: 'TIMEOUT_ERROR',
      message: 'Request timed out. Please try again.',
    }
  }

  // HTTP errors with response
  if (error && typeof error === 'object' && 'status' in error) {
    const httpError = error as { status: number; statusText?: string; data?: unknown }
    return {
      code: 'HTTP_ERROR',
      message: httpError.statusText || 'An error occurred',
      status: httpError.status,
      details: httpError.data,
    }
  }

  // Unknown errors
  if (error instanceof Error) {
    return {
      code: 'UNKNOWN_ERROR',
      message: error.message || 'An unexpected error occurred',
    }
  }

  return {
    code: 'UNKNOWN_ERROR',
    message: 'An unexpected error occurred',
  }
}

/**
 * Sleep utility for retry backoff
 */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * API Client Class
 */
export class ApiClient {
  private config: Required<ApiClientConfig>

  constructor(config: ApiClientConfig = {}) {
    this.config = {
      baseUrl: config.baseUrl || '',
      timeout: config.timeout || 30000,
      retries: config.retries || 3,
      retryDelay: config.retryDelay || 1000,
    }
  }

  /**
   * Make HTTP request with retry logic
   */
  private async request<T>(
    method: string,
    url: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const fullUrl = this.config.baseUrl + url
    let lastError: unknown

    for (let attempt = 0; attempt <= this.config.retries; attempt++) {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), this.config.timeout)

      try {
        logger.debug(`API request attempt ${attempt + 1}`, { method, url, attempt })

        const response = await fetch(fullUrl, {
          ...options,
          method,
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
            ...options.headers,
          },
        })

        clearTimeout(timeoutId)

        // Handle HTTP errors
        if (!response.ok) {
          const errorData = await response.json().catch(() => null)
          throw {
            status: response.status,
            statusText: response.statusText,
            data: errorData,
          }
        }

        // Parse successful response
        const data = await response.json()

        logger.debug('API request succeeded', { method, url, status: response.status })

        return {
          success: true,
          data,
          timestamp: new Date().toISOString(),
        }
      } catch (error) {
        clearTimeout(timeoutId)
        lastError = error

        // Don't retry on client errors (4xx)
        if (error && typeof error === 'object' && 'status' in error) {
          const status = (error as { status: number }).status
          if (status >= 400 && status < 500) {
            logger.warn('API request failed with client error', { method, url, status })
            break
          }
        }

        // Wait before retrying (exponential backoff)
        if (attempt < this.config.retries) {
          const delay = this.config.retryDelay * Math.pow(2, attempt)
          logger.debug(`Retrying request after ${delay}ms`, { method, url, attempt })
          await sleep(delay)
        }
      }
    }

    // All retries failed
    const apiError = normalizeError(lastError)
    logger.error('API request failed after all retries', lastError as Error, {
      method,
      url,
      error: apiError,
    })

    return {
      success: false,
      error: apiError,
      timestamp: new Date().toISOString(),
    }
  }

  /**
   * GET request
   */
  async get<T>(url: string, options?: RequestInit): Promise<ApiResponse<T>> {
    return this.request<T>('GET', url, options)
  }

  /**
   * POST request
   */
  async post<T>(url: string, data?: unknown, options?: RequestInit): Promise<ApiResponse<T>> {
    return this.request<T>('POST', url, {
      ...options,
      body: JSON.stringify(data),
    })
  }

  /**
   * PUT request
   */
  async put<T>(url: string, data?: unknown, options?: RequestInit): Promise<ApiResponse<T>> {
    return this.request<T>('PUT', url, {
      ...options,
      body: JSON.stringify(data),
    })
  }

  /**
   * DELETE request
   */
  async delete<T>(url: string, options?: RequestInit): Promise<ApiResponse<T>> {
    return this.request<T>('DELETE', url, options)
  }
}

// Default API client instance
export const apiClient = new ApiClient()
