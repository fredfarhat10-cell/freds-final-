/**
 * Error Tracking Integration
 * 
 * Integrates with error tracking service (Sentry) in production.
 * Filters sensitive data before sending errors.
 */

import { env, isProduction } from './env'
import { logger } from './logger'

// Sample rate for performance monitoring
const TRACES_SAMPLE_RATE = 0.1 // 10%

/**
 * Initialize error tracking
 * Only initializes in production with valid DSN
 */
export function initErrorTracking(): void {
  if (!isProduction || !env.SENTRY_DSN) {
    logger.info('Error tracking disabled (development mode or no DSN)')
    return
  }

  try {
    // Note: In a real app, you would initialize Sentry here
    // import * as Sentry from '@sentry/nextjs'
    // 
    // Sentry.init({
    //   dsn: env.SENTRY_DSN,
    //   environment: env.NODE_ENV,
    //   tracesSampleRate: TRACES_SAMPLE_RATE,
    //   beforeSend(event) {
    //     return filterSensitiveData(event)
    //   },
    // })

    logger.info('Error tracking initialized', { dsn: env.SENTRY_DSN })
  } catch (error) {
    logger.error('Failed to initialize error tracking', error as Error)
  }
}

/**
 * Filter sensitive data from error events
 */
function filterSensitiveData(event: unknown): unknown {
  // In a real implementation, this would filter out:
  // - Authorization headers
  // - Cookies
  // - API keys
  // - Personal information
  return event
}

/**
 * Capture exception and send to error tracking service
 */
export function captureException(error: Error, context?: Record<string, unknown>): void {
  if (!isProduction) {
    logger.error('Exception captured (dev mode)', error, context)
    return
  }

  try {
    // Note: In a real app, you would use Sentry here
    // import * as Sentry from '@sentry/nextjs'
    // Sentry.captureException(error, { extra: context })

    logger.error('Exception captured and sent to tracking service', error, context)
  } catch (trackingError) {
    logger.error('Failed to capture exception', trackingError as Error, { originalError: error.message })
  }
}

/**
 * Capture message for non-error events
 */
export function captureMessage(message: string, level: 'info' | 'warning' | 'error' = 'info'): void {
  if (!isProduction) {
    logger.info(`Message captured (dev mode): ${message}`, { level })
    return
  }

  try {
    // Note: In a real app, you would use Sentry here
    // import * as Sentry from '@sentry/nextjs'
    // Sentry.captureMessage(message, level)

    logger.info('Message captured and sent to tracking service', { message, level })
  } catch (trackingError) {
    logger.error('Failed to capture message', trackingError as Error, { originalMessage: message })
  }
}
