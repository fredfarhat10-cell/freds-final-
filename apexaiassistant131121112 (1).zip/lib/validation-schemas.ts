/**
 * Zod Validation Schemas
 * 
 * Centralized validation schemas for all data types in the application.
 * Provides type-safe validation with helpful error messages.
 */

import { z } from 'zod'

// User profile schema
export const userProfileSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1, 'Name is required').max(100, 'Name is too long'),
  email: z.string().email('Invalid email address'),
  preferences: z.object({
    theme: z.enum(['light', 'dark', 'system']).default('system'),
    notifications: z.boolean().default(true),
    language: z.string().default('en'),
  }).optional(),
})

export type UserProfile = z.infer<typeof userProfileSchema>

// Portfolio data schema
export const portfolioSchema = z.object({
  assets: z.array(z.object({
    id: z.string(),
    name: z.string(),
    symbol: z.string().optional(),
    value: z.number().positive(),
    change: z.number(),
    changePercent: z.number(),
  })),
  totalValue: z.number().positive(),
  totalChange: z.number(),
  totalChangePercent: z.number(),
})

export type Portfolio = z.infer<typeof portfolioSchema>

// Transaction data schema
export const transactionSchema = z.object({
  id: z.string().uuid().optional(),
  amount: z.number(),
  date: z.string().datetime().or(z.date()),
  category: z.string().min(1, 'Category is required'),
  merchant: z.string().optional(),
  description: z.string().optional(),
  type: z.enum(['income', 'expense', 'transfer']),
})

export type Transaction = z.infer<typeof transactionSchema>

// Calendar event schema
export const calendarEventSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().min(1, 'Title is required').max(200, 'Title is too long'),
  start: z.string().datetime().or(z.date()),
  end: z.string().datetime().or(z.date()),
  description: z.string().max(1000, 'Description is too long').optional(),
  location: z.string().optional(),
  attendees: z.array(z.string().email()).optional(),
})

export type CalendarEvent = z.infer<typeof calendarEventSchema>

// Common API request schemas
export const paginationSchema = z.object({
  page: z.number().int().positive().default(1),
  limit: z.number().int().positive().max(100).default(20),
})

export type Pagination = z.infer<typeof paginationSchema>

export const dateRangeSchema = z.object({
  startDate: z.string().datetime().or(z.date()),
  endDate: z.string().datetime().or(z.date()),
}).refine(data => new Date(data.startDate) <= new Date(data.endDate), {
  message: 'Start date must be before or equal to end date',
})

export type DateRange = z.infer<typeof dateRangeSchema>

// Settings schema
export const settingsSchema = z.object({
  theme: z.enum(['light', 'dark', 'system']).default('system'),
  notifications: z.object({
    email: z.boolean().default(true),
    push: z.boolean().default(true),
    sms: z.boolean().default(false),
  }),
  language: z.string().default('en'),
  timezone: z.string().default('UTC'),
})

export type Settings = z.infer<typeof settingsSchema>
