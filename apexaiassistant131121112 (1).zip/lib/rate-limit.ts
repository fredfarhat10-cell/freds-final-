/**
 * Rate Limiting Middleware
 * 
 * Uses LRU cache to track request counts per token (IP or user ID).
 * Protects API routes from abuse with configurable limits.
 */

import { LRUCache } from 'lru-cache'
import { logger } from './logger'

export interface RateLimitConfig {
  interval: number // Time window in milliseconds
  uniqueTokenPerInterval: number // Max unique tokens to track
}

export interface RateLimitResult {
  success: boolean
  remaining: number
  resetAt?: number
}

/**
 * Create a rate limiter instance
 */
export function rateLimit(config: RateLimitConfig = { interval: 60000, uniqueTokenPerInterval: 500 }) {
  const cache = new LRUCache<string, number[]>({
    max: config.uniqueTokenPerInterval,
    ttl: config.interval,
  })

  return {
    /**
     * Check if request is allowed
     * @param request - Request object to extract token from
     * @param limit - Maximum requests allowed in interval
     * @returns Rate limit result
     */
    check: async (request: Request, limit: number = 10): Promise<RateLimitResult> => {
      // Extract token from request (use IP address or custom header)
      const token = getToken(request)
      
      if (!token) {
        logger.warn('Rate limit: Unable to extract token from request')
        return { success: true, remaining: limit } // Allow if we can't identify
      }

      const now = Date.now()
      const timestamps = cache.get(token) || []
      
      // Filter out timestamps outside the current interval
      const validTimestamps = timestamps.filter(time => now - time < config.interval)
      
      // Check if limit exceeded
      if (validTimestamps.length >= limit) {
        const oldestTimestamp = validTimestamps[0]
        const resetAt = oldestTimestamp + config.interval

        logger.warn('Rate limit exceeded', { token, limit, count: validTimestamps.length })

        return {
          success: false,
          remaining: 0,
          resetAt,
        }
      }

      // Add current timestamp
      validTimestamps.push(now)
      cache.set(token, validTimestamps)

      const remaining = limit - validTimestamps.length

      logger.debug('Rate limit check passed', { token, remaining, limit })

      return {
        success: true,
        remaining,
      }
    },
  }
}

/**
 * Extract token from request (IP address or custom header)
 */
function getToken(request: Request): string | null {
  // Try to get IP from various headers
  const forwardedFor = request.headers.get('x-forwarded-for')
  if (forwardedFor) {
    return forwardedFor.split(',')[0].trim()
  }

  const realIp = request.headers.get('x-real-ip')
  if (realIp) {
    return realIp
  }

  // Try custom user ID header
  const userId = request.headers.get('x-user-id')
  if (userId) {
    return userId
  }

  // Fallback to a generic identifier
  return 'anonymous'
}
