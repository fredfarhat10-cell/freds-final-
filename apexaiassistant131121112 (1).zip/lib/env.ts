/**
 * Environment Variable Validation System
 * 
 * This module validates all environment variables on startup using Zod schemas.
 * Provides type-safe access to environment variables throughout the application.
 * Fails fast with clear error messages if any required variables are missing or invalid.
 */

import { z } from 'zod'

// Define the schema for environment variables
const envSchema = z.object({
  // Node environment
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  
  // Google OAuth (Required)
  GOOGLE_CLIENT_ID: z.string().min(1, 'GOOGLE_CLIENT_ID is required'),
  GOOGLE_CLIENT_SECRET: z.string().min(1, 'GOOGLE_CLIENT_SECRET is required'),
  
  // Plaid (Required)
  PLAID_CLIENT_ID: z.string().min(1, 'PLAID_CLIENT_ID is required'),
  PLAID_SECRET: z.string().min(1, 'PLAID_SECRET is required'),
  
  // OpenAI (Required)
  OPENAI_API_KEY: z.string().min(1, 'OPENAI_API_KEY is required'),
  
  // App Configuration (Required)
  NEXT_PUBLIC_APP_URL: z.string().url('NEXT_PUBLIC_APP_URL must be a valid URL'),
  
  // Optional Configuration
  NEXT_PUBLIC_DEMO_MODE: z.string().optional().transform(val => val === 'true'),
  CREWAI_BACKEND_URL: z.string().url().optional(),
  SENTRY_DSN: z.string().url().optional(),
})

// Type inference from schema
export type Env = z.infer<typeof envSchema>

/**
 * Validate and parse environment variables
 * This runs immediately on module load to fail fast if config is invalid
 */
function validateEnv(): Env {
  const parsed = envSchema.safeParse({
    NODE_ENV: process.env.NODE_ENV,
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET: process.env.GOOGLE_CLIENT_SECRET,
    PLAID_CLIENT_ID: process.env.PLAID_CLIENT_ID,
    PLAID_SECRET: process.env.PLAID_SECRET,
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    NEXT_PUBLIC_DEMO_MODE: process.env.NEXT_PUBLIC_DEMO_MODE,
    CREWAI_BACKEND_URL: process.env.CREWAI_BACKEND_URL,
    SENTRY_DSN: process.env.SENTRY_DSN,
  })

  if (!parsed.success) {
    console.error('❌ Invalid environment variables:', parsed.error.flatten().fieldErrors)
    throw new Error('Invalid environment variables')
  }

  return parsed.data
}

// Validate and export typed environment variables
export const env = validateEnv()

// Type-safe environment access for use throughout the app
export const isProduction = env.NODE_ENV === 'production'
export const isDevelopment = env.NODE_ENV === 'development'
export const isTest = env.NODE_ENV === 'test'
export const isDemoMode = env.NEXT_PUBLIC_DEMO_MODE || false
