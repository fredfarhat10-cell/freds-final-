/**
 * Structured Logging System
 * 
 * Replaces all console statements with structured logging.
 * - Development: Logs to console with colors
 * - Production: Sends to error tracking service
 * - Never logs sensitive data (strips tokens, passwords)
 */

import { env, isProduction } from './env'

// Log levels
export enum LogLevel {
  DEBUG = 'DEBUG',
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR',
}

// Log entry structure
interface LogEntry {
  level: LogLevel
  message: string
  timestamp: string
  context?: Record<string, unknown>
  error?: Error
}

// Sensitive fields to strip from logs
const SENSITIVE_FIELDS = [
  'password',
  'token',
  'apiKey',
  'secret',
  'authorization',
  'cookie',
  'session',
]

/**
 * Strip sensitive data from context before logging
 */
function sanitizeContext(context?: Record<string, unknown>): Record<string, unknown> | undefined {
  if (!context) return undefined

  const sanitized = { ...context }
  
  for (const key of Object.keys(sanitized)) {
    const lowerKey = key.toLowerCase()
    if (SENSITIVE_FIELDS.some(field => lowerKey.includes(field))) {
      sanitized[key] = '[REDACTED]'
    }
  }

  return sanitized
}

/**
 * Format log entry for console output
 */
function formatConsoleLog(entry: LogEntry): string {
  const colors = {
    [LogLevel.DEBUG]: '\x1b[36m', // Cyan
    [LogLevel.INFO]: '\x1b[32m',  // Green
    [LogLevel.WARN]: '\x1b[33m',  // Yellow
    [LogLevel.ERROR]: '\x1b[31m', // Red
  }
  const reset = '\x1b[0m'

  const color = colors[entry.level]
  const prefix = `${color}[${entry.level}]${reset}`
  const timestamp = `\x1b[90m${entry.timestamp}${reset}`
  
  let message = `${timestamp} ${prefix} ${entry.message}`
  
  if (entry.context) {
    message += `\n  Context: ${JSON.stringify(entry.context, null, 2)}`
  }
  
  if (entry.error) {
    message += `\n  Error: ${entry.error.message}`
    if (entry.error.stack) {
      message += `\n  Stack: ${entry.error.stack}`
    }
  }

  return message
}

/**
 * Send log to production service
 */
function sendToProduction(entry: LogEntry): void {
  // In production, send to error tracking service
  if (env.SENTRY_DSN && entry.level === LogLevel.ERROR && entry.error) {
    // This will be handled by error-tracking.ts
    // For now, we'll just use console.error as fallback
    console.error(JSON.stringify(entry))
  }
}

/**
 * Core logging function
 */
function log(level: LogLevel, message: string, error?: Error, context?: Record<string, unknown>): void {
  const entry: LogEntry = {
    level,
    message,
    timestamp: new Date().toISOString(),
    context: sanitizeContext(context),
    error,
  }

  if (isProduction) {
    sendToProduction(entry)
  } else {
    console.log(formatConsoleLog(entry))
  }
}

/**
 * Logger API
 */
export const logger = {
  /**
   * Debug level logging - for detailed diagnostic information
   */
  debug: (message: string, context?: Record<string, unknown>): void => {
    log(LogLevel.DEBUG, message, undefined, context)
  },

  /**
   * Info level logging - for general informational messages
   */
  info: (message: string, context?: Record<string, unknown>): void => {
    log(LogLevel.INFO, message, undefined, context)
  },

  /**
   * Warning level logging - for potentially harmful situations
   */
  warn: (message: string, context?: Record<string, unknown>): void => {
    log(LogLevel.WARN, message, undefined, context)
  },

  /**
   * Error level logging - for error events
   */
  error: (message: string, error?: Error, context?: Record<string, unknown>): void => {
    log(LogLevel.ERROR, message, error, context)
  },
}
