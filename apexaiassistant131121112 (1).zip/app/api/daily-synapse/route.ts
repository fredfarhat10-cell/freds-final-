import { type NextRequest, NextResponse } from "next/server"

const isDemoMode = process.env.NEXT_PUBLIC_DEMO_MODE === "true"

const mockDailySynapse = {
  date: new Date().toISOString(),
  stateOfUnion:
    "Your portfolio gained 2.3% overnight while you achieved your best sleep score this week. Today brings 4 meetings but also a 3-hour deep work window. The synergy between your wellness and productivity metrics suggests this is your moment to tackle complex challenges.",
  guildStatus: {
    financial: {
      status: "Strong",
      metric: "Portfolio +2.3% | Budget 78% utilized",
    },
    career: {
      status: "Busy",
      metric: "4 meetings scheduled | 3h deep work available",
    },
    wellness: {
      status: "Excellent",
      metric: "Sleep: 88% | Energy: High",
    },
    social: {
      status: "Active",
      metric: "2 connections pending | 3 messages",
    },
    time: {
      status: "Moderate",
      metric: "Calendar density: 65% | 5h free time",
    },
    goals: {
      status: "On Track",
      metric: "Q1 Progress: 62% | 3 milestones ahead",
    },
  },
  crossGuildInsight:
    "Your exceptional 8.5hr sleep score combined with a light meeting load creates perfect conditions for tackling that complex financial model you've been postponing. Your cognitive performance peaks align with your morning deep work block.",
  priorities: {
    topPriority: "Complete financial model during morning deep work block (9-12am)",
    opportunities: [
      "Review portfolio gains and consider rebalancing tech sector",
      "Connect with 2 pending LinkedIn requests from industry leaders",
      "Schedule Q2 planning session while energy is high",
    ],
    risks: [
      "Back-to-back meetings 2-4pm may drain energy reserves",
      "Email backlog could derail morning focus if not addressed early",
      "Afternoon energy dip predicted around 3pm - plan accordingly",
    ],
  },
  energyStrategy: {
    morning: "High Energy Zone: Deep work on complex tasks, strategic thinking, creative problem-solving",
    afternoon: "Moderate Energy: Meetings, collaboration, routine tasks, email processing",
    evening: "Recovery Mode: Light admin, planning tomorrow, reflection, wind-down activities",
  },
  closingMotivation:
    "You're operating at peak capacity today. Trust your preparation, leverage your energy wisely, and remember: excellence is built in moments like these.",
}

export async function POST(request: NextRequest) {
  if (isDemoMode) {
    // Demo mode: return mock data
    await new Promise((resolve) => setTimeout(resolve, 1500))
    return NextResponse.json({
      success: true,
      synapse: mockDailySynapse,
    })
  }

  try {
    // Live mode: call CrewAI backend
    const { userId } = await request.json()

    const backendUrl = process.env.CREWAI_BACKEND_URL || "http://localhost:8000"
    const response = await fetch(`${backendUrl}/api/synapse/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId }),
    })

    if (!response.ok) {
      throw new Error("Backend request failed")
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Daily Synapse API error:", error)

    // Fallback to mock data on error
    return NextResponse.json({
      success: true,
      synapse: mockDailySynapse,
      fallback: true,
    })
  }
}
