import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { userId, sessionId } = await request.json()

    // In production, this would call the CrewAI backend
    // For now, we'll return a mock response structure
    const crewAIEndpoint = process.env.CREWAI_BACKEND_URL || "http://localhost:8000"

    const response = await fetch(`${crewAIEndpoint}/api/weekly-sync`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        user_name: userId,
        session_id: sessionId,
      }),
    })

    if (!response.ok) {
      throw new Error("CrewAI backend request failed")
    }

    const report = await response.json()

    return NextResponse.json({ report })
  } catch (error) {
    console.error("[v0] Error generating weekly sync report:", error)
    return NextResponse.json({ error: "Failed to generate weekly sync report" }, { status: 500 })
  }
}
