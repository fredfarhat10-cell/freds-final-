import ApexFinancialStudio from "@/components/apex-financial-studio"

export default function FinancialStudioPage() {
  return <ApexFinancialStudio />
}
