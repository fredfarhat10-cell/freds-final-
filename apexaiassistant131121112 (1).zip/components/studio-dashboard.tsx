"use client"

import { useState, useEffect, useRef } from "react"
import { useVault } from "@/lib/vault-context"
import Sidebar from "@/components/sidebar"
import HelpCenter from "@/components/help-center"
import FinancialStudio from "@/components/studios/financial-studio"
import CareerGuild from "@/components/career-guild"
import AlphaBriefsStudio from "@/components/studios/alpha-briefs-studio" // Import AlphaBriefsStudio component
import { getScheduler } from "@/lib/apex-scheduler"
import { TrendAnalyzer } from "@/lib/trend-analyzer"
import { VoiceEngine } from "@/lib/voice-engine"
import { VoiceGenerator, type EmotionalState } from "@/lib/voice-generator"
import { playSound, isSoundEnabled, setSoundEnabled } from "@/lib/sound-manager"
import { Volume2Icon, VolumeXIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import ProactiveInsightsPanel from "@/components/proactive-insights-panel"
import ApexOverlay from "@/components/apex-overlay"
import { ProactiveNotifications } from "@/components/proactive-notifications"
import DailySynapse from "@/components/daily-synapse"
import { motion } from "framer-motion"

interface Notification {
  id: number
  level: "POS" | "NEU" | "ALR"
  title: string
  body: string
  detail: string
  module: "performance" | "portfolio" | "wellness"
  date: string
}

type Mood = "calm" | "alert" | "happy"

export default function StudioDashboard() {
  const { userProfile, strategicGoal, expenses, habits, habitLogs, moodHistory, trendAnalysis, updateState, aura } =
    useVault()
  const [activeTab, setActiveTab] = useState("dashboard")
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [selected, setSelected] = useState<Notification | null>(null)
  const [time, setTime] = useState(new Date())
  const [weather] = useState("18°C")
  const [mood, setMood] = useState<Mood>("calm")
  const [speaking, setSpeaking] = useState(false)
  const [soundEnabled, setSoundEnabledState] = useState(isSoundEnabled())
  const voiceEngine = useRef(new VoiceEngine())

  const [crewIsRunning, setCrewIsRunning] = useState(false)
  const [crewResult, setCrewResult] = useState("")

  const [showDailySynapse, setShowDailySynapse] = useState(false)
  const [synapseShownToday, setSynapseShownToday] = useState(false)

  const handleJobRun = async (action: string) => {
    console.log(`[v0] Scheduler is running action: ${action}`)
    speak(`Autonomous check: Running ${action.replace(/_/g, " ")}...`, "analytical")
    setMood("alert")

    try {
      const response = await fetch("/api/proactive-check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          userId: userProfile?.name || "current-user",
        }),
      })

      const data = await response.json()

      if (data.success && data.notification) {
        speak("Autonomous check complete. New insight available.", "celebratory")
        setMood("happy")
        window.dispatchEvent(new CustomEvent("new-proactive-notification", { detail: data.notification }))
      } else {
        speak("Autonomous check complete.", "neutral")
        setMood("calm")
      }
    } catch (error) {
      console.error("[v0] Proactive check failed:", error)
      speak("Autonomous check encountered an issue.", "warning")
      setMood("calm")
    }
  }

  useEffect(() => {
    const scheduler = getScheduler(handleJobRun)
    scheduler.start()
    return () => scheduler.stop()
  }, [])

  useEffect(() => {
    const checkAndShowSynapse = () => {
      const today = new Date().toDateString()
      const lastShown = localStorage.getItem("lastSynapseShown")

      if (lastShown !== today && !synapseShownToday) {
        setTimeout(() => {
          setShowDailySynapse(true)
          setSynapseShownToday(true)
          localStorage.setItem("lastSynapseShown", today)
        }, 2000)
      }
    }

    checkAndShowSynapse()
  }, [synapseShownToday])

  const handleComplexRequest = async (requestText: string) => {
    setCrewIsRunning(true)
    speak("Initiating deep analysis. My specialized agents are on it...", "analytical")
    setMood("alert")

    try {
      const user_context = {
        user_name: userProfile?.name || "User",
        fitness_goals: strategicGoal || "General wellness",
        user_location: userProfile?.country || "Unknown",
        occupation: userProfile?.occupation || "Not specified",
        interests: userProfile?.interests || [],
        skills: userProfile?.skills || [],
        financial_risk_style: userProfile?.financialRiskStyle || "Moderate",
        total_expenses: expenses?.reduce((sum, exp) => sum + exp.amount, 0) || 0,
        active_habits: habits?.length || 0,
        current_aura: moodHistory?.[0]?.aura || "Neutral",
      }

      const response = await fetch("/api/crewai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_request: requestText,
          user_context: user_context,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setCrewResult(result.result)
        speak("Analysis complete. Here is the synthesized intelligence from my team.", "celebratory")
        setMood("happy")
      } else {
        throw new Error(result.error)
      }
    } catch (error) {
      speak("There was an issue coordinating with my specialist team. Please try again.", "warning")
      setMood("alert")
      console.error("[v0] CrewAI mission failed:", error)
    } finally {
      setCrewIsRunning(false)
    }
  }

  useEffect(() => {
    const runAnalysis = () => {
      const fullState = {
        expenses: expenses || [],
        habits: habits || [],
        habitLogs: habitLogs || [],
        moodHistory: moodHistory || [],
        aura: "Neutral" as const,
      }
      const analysis = TrendAnalyzer.analyze(fullState as any)
      updateState("trendAnalysis", analysis)
    }

    runAnalysis()
    const interval = setInterval(runAnalysis, 60000)
    return () => clearInterval(interval)
  }, [expenses, habits, habitLogs, moodHistory, updateState])

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    const safeHabits = habits || []
    const safeHabitLogs = habitLogs || []
    const safeExpenses = expenses || []

    const todayStr = new Date().toISOString().split("T")[0]
    const completedToday = safeHabitLogs.filter((log) => log.date === todayStr && log.completed).length
    const totalExpenses = safeExpenses.reduce((sum, exp) => sum + exp.amount, 0)

    const base: Notification[] = [
      {
        id: 1,
        level: "POS",
        title: "Focus Trending ↑",
        body: `You completed ${completedToday} of ${safeHabits.length} habits today. Keep up the momentum!`,
        detail: `Apex analysis shows your habit completion rate is strong. You've maintained consistent productivity this week. Momentum looks sustainable and aligns with your goal.`,
        module: "performance",
        date: "Today",
      },
      {
        id: 2,
        level: "NEU",
        title: "Market Calm",
        body: "Volatility index remains stable. Suitable for long-term planning.",
        detail:
          "No major macro shifts detected. Today is ideal for reflection and planning future allocations based on your risk profile.",
        module: "portfolio",
        date: "Today",
      },
    ]

    if (totalExpenses > 1000) {
      base.push({
        id: 3,
        level: "ALR",
        title: "Sleep Debt Detected",
        body: `Sleep quality dipped 8% below your baseline.`,
        detail: `Reduced recovery detected. Apex suggests a mindfulness block or an earlier shutdown tonight to maintain peak cognitive function.`,
        module: "wellness",
        date: "Today",
      })
    }

    setNotifications(base)
  }, [habits, habitLogs, expenses])

  function speak(text: string, emotionalState: EmotionalState = "neutral") {
    VoiceGenerator.speak(
      text,
      aura || "Neutral",
      emotionalState,
      () => setSpeaking(true),
      () => setSpeaking(false),
    )
  }

  const handleExplain = (topic: string, data: string) => {
    playSound("click")
    let explanation = ""
    let emotionalState: EmotionalState = "analytical"

    switch (topic) {
      case "portfolio":
        explanation = `Your portfolio's current value is based on the real-time simulated market data. The daily change reflects its performance against yesterday's close. Your risk level is currently assessed as ${data}.`
        emotionalState = "analytical"
        break
      case "goals":
        explanation = `This shows your progress towards your financial goal. You are currently ${data} percent of the way there. I am continuously forecasting your trajectory to see if you are on track.`
        emotionalState = "motivational"
        break
      case "insights":
        explanation = `These are proactive insights I generate by analyzing your data patterns. The priority level indicates how important I believe this information is for your current strategy.`
        emotionalState = "analytical"
        break
      case "habits":
        explanation = `You completed ${data} habits today. Maintaining consistency is key to long-term success. I'm tracking your patterns to help optimize your routine.`
        emotionalState = "motivational"
        break
    }
    speak(explanation, emotionalState)
  }

  const toggleSound = () => {
    const newState = !soundEnabled
    setSoundEnabledState(newState)
    setSoundEnabled(newState)
    playSound(newState ? "success" : "click")
  }

  const hour = time.getHours()
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening"

  const location = userProfile?.country || "London, UK"
  const greetWord = location.toLowerCase().includes("italy")
    ? "Ciao"
    : location.toLowerCase().includes("india")
      ? "Namaste"
      : greeting

  const partOfDay = hour < 12 ? "morning" : hour < 18 ? "afternoon" : "evening"

  const orbColor =
    mood === "calm"
      ? "from-blue-500 via-purple-600 to-blue-700"
      : mood === "alert"
        ? "from-red-500 via-orange-500 to-yellow-500"
        : "from-green-400 via-teal-500 to-blue-400"

  const interest = strategicGoal || "your focus area"

  const getMoodLine = () => {
    if (trendAnalysis?.recommendations && trendAnalysis.recommendations.length > 0) {
      return trendAnalysis.recommendations[0]
    }

    switch (mood) {
      case "alert":
        return `Stay sharp. I'm monitoring for changes around ${interest}.`
      case "calm":
        return `Systems are steady. A good moment to think ahead on ${interest}.`
      case "happy":
        return `Positive momentum detected. Let's keep the progress on ${interest} flowing.`
      default:
        return `Ready when you are.`
    }
  }

  const renderContent = () => {
    switch (activeTab) {
      case "help":
        return <HelpCenter />
      case "financial":
        return <FinancialStudio />
      case "career":
        return <CareerGuild />
      case "goals":
        return <PlaceholderPage title="Goals" />
      case "alpha-briefs":
        return <AlphaBriefsStudio />
      case "settings":
        return <PlaceholderPage title="Settings" />
      case "dashboard":
      default:
        return (
          <div className="relative h-screen w-full text-white overflow-y-auto font-mono flex flex-col items-center pt-6 pb-12 animate-fadeIn">
            <div
              className="absolute inset-0 z-0"
              style={{
                background: "radial-gradient(ellipse at center, #1a1a3a 0%, #0a0a1a 70%)",
              }}
            />

            {Array.from({ length: 50 }, (_, i) => ({
              id: i,
              x: Math.random() * 100,
              y: Math.random() * 100,
              duration: 20 + Math.random() * 30,
            })).map((particle) => (
              <motion.div
                key={particle.id}
                className="absolute w-0.5 h-0.5 bg-cyan-400/40 rounded-full z-0"
                initial={{
                  x: `${particle.x}vw`,
                  y: `${particle.y}vh`,
                }}
                animate={{
                  y: [`${particle.y}vh`, `${(particle.y + 50) % 100}vh`],
                  opacity: [0.2, 0.5, 0.2],
                }}
                transition={{
                  duration: particle.duration,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "linear",
                }}
              />
            ))}

            <div className="absolute top-6 right-6 z-20 flex items-center gap-2">
              <ProactiveNotifications />
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleSound}
                className="text-gray-400 hover:text-white transition-colors"
              >
                {soundEnabled ? <Volume2Icon className="w-5 h-5" /> : <VolumeXIcon className="w-5 h-5" />}
              </Button>
            </div>

            <div className="relative z-10 w-full max-w-4xl bg-[#0f1118]/80 backdrop-blur-md border border-white/10 rounded-2xl p-6 mb-8 overflow-hidden shadow-2xl">
              <div
                className={`absolute -top-20 -right-20 w-64 h-64 rounded-full bg-gradient-to-r ${orbColor} opacity-20 blur-3xl transition-all duration-1000`}
              />
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <h2 className="text-sm tracking-widest text-gray-400 uppercase">
                    {time.toLocaleDateString(undefined, {
                      weekday: "long",
                      month: "long",
                      day: "numeric",
                    })}
                  </h2>
                  <h1 className="text-5xl md:text-6xl font-extrabold mt-2">
                    {time.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </h1>
                  <p className="text-sm mt-2 text-gray-400">{location.toUpperCase()}</p>
                </div>
                <div className="flex flex-col items-end">
                  <div
                    className={`w-24 h-24 rounded-full bg-gradient-to-r ${orbColor} shadow-inner shadow-blue-400/40 flex items-center justify-center transition-all duration-1000 ${
                      speaking ? "animate-[pulse_1.2s_ease-in-out_infinite]" : "animate-[pulse_4s_ease-in-out_infinite]"
                    }`}
                  >
                    <div className="text-4xl">🧠</div>
                  </div>
                  <p className="text-xs text-gray-400 mt-2">{speaking ? "Speaking..." : "Apex Online"}</p>
                </div>
              </div>
            </div>

            <div className="text-center mb-8 w-full max-w-4xl">
              <h2 className="text-xl font-semibold tracking-wide">
                {greetWord}, {userProfile?.name || "User"}! 👋
              </h2>
              <p className="text-gray-400 text-sm mt-1">"{getMoodLine()}"</p>
            </div>

            {/* Placeholder for Daily Synapse content */}
            <div className="w-full max-w-4xl bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border border-cyan-500/30 rounded-2xl p-6 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-cyan-400">Daily Synapse</h3>
                <button
                  onClick={() => setShowDailySynapse(true)}
                  className="text-xs px-3 py-1 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-400 rounded transition-colors"
                >
                  Show Synapse
                </button>
              </div>
            </div>

            <div className="w-full max-w-4xl bg-[#0f1118]/80 backdrop-blur-md border border-white/10 rounded-2xl p-6">
              <h3 className="text-sm uppercase tracking-widest text-gray-400 mb-4">Intelligence Feed</h3>
              {notifications.length > 0 ? (
                <div className="space-y-3">
                  {notifications.map((n) => (
                    <button
                      key={n.id}
                      onClick={() => {
                        playSound("notification")
                        setSelected(n)
                        speak(`${n.title}. ${n.detail}`)
                      }}
                      className="w-full text-left bg-[#14161e] p-4 rounded-xl border border-white/10 hover:border-blue-400/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span
                          className={`text-xs px-2 py-0.5 rounded font-semibold ${
                            n.level === "POS"
                              ? "bg-green-500/20 text-green-300"
                              : n.level === "ALR"
                                ? "bg-red-500/20 text-red-300"
                                : "bg-blue-500/20 text-blue-300"
                          }`}
                        >
                          {n.level}
                        </span>
                        <span className="text-xs text-gray-500 group-hover:text-gray-300 transition-colors">
                          Click to Expand
                        </span>
                      </div>
                      <h4 className="text-md font-semibold text-white/90">{n.title}</h4>
                      <p className="text-sm text-gray-400 mt-1">{n.body}</p>
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-sm text-center py-4">All systems quiet. Apex is monitoring.</p>
              )}
            </div>

            <div className="w-full max-w-6xl mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card
                  onClick={() => {
                    const completedToday = (habitLogs || []).filter(
                      (log) => log.date === new Date().toISOString().split("T")[0] && log.completed,
                    ).length
                    handleExplain("habits", completedToday.toString())
                  }}
                  className="bg-[#0f1118]/80 backdrop-blur-md border border-white/10 p-6 cursor-pointer hover:border-cyan-400/50 transition-all"
                >
                  <h3 className="text-sm uppercase tracking-widest text-gray-400 mb-2">Habits Today</h3>
                  <p className="text-3xl font-bold">
                    {
                      (habitLogs || []).filter(
                        (log) => log.date === new Date().toISOString().split("T")[0] && log.completed,
                      ).length
                    }{" "}
                    / {(habits || []).length}
                  </p>
                  <p className="text-xs text-gray-500 mt-2">Click to hear analysis</p>
                </Card>

                <Card
                  onClick={() => handleExplain("goals", "62")}
                  className="bg-[#0f1118]/80 backdrop-blur-md border border-white/10 p-6 cursor-pointer hover:border-purple-400/50 transition-all"
                >
                  <h3 className="text-sm uppercase tracking-widest text-gray-400 mb-2">Goal Progress</h3>
                  <p className="text-3xl font-bold">62%</p>
                  <p className="text-xs text-gray-500 mt-2">Click to hear analysis</p>
                </Card>

                <Card
                  onClick={() => handleExplain("insights", "Active")}
                  className="bg-[#0f1118]/80 backdrop-blur-md border border-white/10 p-6 cursor-pointer hover:border-pink-400/50 transition-all"
                >
                  <h3 className="text-sm uppercase tracking-widest text-gray-400 mb-2">Active Insights</h3>
                  <p className="text-3xl font-bold">{trendAnalysis?.recommendations?.length || 0}</p>
                  <p className="text-xs text-gray-500 mt-2">Click to hear analysis</p>
                </Card>
              </div>
            </div>

            <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              <div className="lg:col-span-2">
                <div className="bg-[#0f1118]/80 backdrop-blur-md border border-white/10 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm uppercase tracking-widest text-gray-400">Notifications</h3>
                    <button
                      onClick={() => {
                        playSound("click")
                        setNotifications([])
                      }}
                      className="text-xs text-gray-500 hover:text-gray-300 transition-colors"
                    >
                      Clear All
                    </button>
                  </div>

                  {notifications.length ? (
                    <div className="space-y-3">
                      {notifications.map((n) => (
                        <button
                          key={n.id}
                          onClick={() => {
                            playSound("notification")
                            setSelected(n)
                            speak(`${n.title}. ${n.detail}`)
                          }}
                          className="w-full text-left bg-[#14161e] p-4 rounded-xl border border-white/10 hover:border-blue-400/50 transition-all group"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span
                              className={`text-xs px-2 py-0.5 rounded font-semibold ${
                                n.level === "POS"
                                  ? "bg-green-500/20 text-green-300"
                                  : n.level === "ALR"
                                    ? "bg-red-500/20 text-red-300"
                                    : "bg-blue-500/20 text-blue-300"
                              }`}
                            >
                              {n.level}
                            </span>
                            <span className="text-xs text-gray-500 group-hover:text-gray-300 transition-colors">
                              Click to Expand
                            </span>
                          </div>
                          <h4 className="text-md font-semibold text-white/90">{n.title}</h4>
                          <p className="text-sm text-gray-400 mt-1">{n.body}</p>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm text-center py-4">All systems quiet. Apex is monitoring.</p>
                  )}

                  <div className="mt-6 pt-6 border-t border-white/10">
                    <h4 className="text-xs uppercase tracking-widest text-gray-400 mb-3">Deep Analysis</h4>
                    <Button
                      onClick={() =>
                        handleComplexRequest("Analyze my current situation and suggest one key improvement.")
                      }
                      disabled={crewIsRunning}
                      className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      {crewIsRunning ? "Agents Working..." : "Run Deep Analysis"}
                    </Button>

                    {crewResult && (
                      <div className="mt-4 bg-[#14161e] p-4 rounded-xl border border-purple-400/30">
                        <p className="text-xs uppercase tracking-widest text-purple-400 mb-2">Agent Report</p>
                        <p className="text-sm text-gray-300 leading-relaxed">{crewResult}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <ProactiveInsightsPanel />
              </div>
            </div>

            <p className="text-xs text-gray-500 mt-6">⏺ Apex Mission Console v4.0 — Voice Interface Active</p>

            {selected && (
              <ApexOverlay item={selected} onClose={() => setSelected(null)} setMood={setMood} speak={speak} />
            )}
          </div>
        )
    }
  }

  return (
    <div className="flex h-screen bg-apex-darker">
      <Sidebar currentPage={activeTab} setCurrentPage={setActiveTab} />
      <main className="flex-1 overflow-y-auto">{renderContent()}</main>

      {showDailySynapse && <DailySynapse onClose={() => setShowDailySynapse(false)} />}
    </div>
  )
}

function getPageTitle(page: string): string {
  const titles: Record<string, string> = {
    strategy: "Strategy",
    activities: "Activities",
    calendar: "Calendar",
    stylist: "Stylist",
    knowledge: "Knowledge",
    routines: "Routines",
    simulator: "Simulator",
    privacy: "Privacy Center",
    security: "Security Center",
    vault: "Vault",
    automations: "Automations",
    career: "Career Guild",
    goals: "Goals",
    alphaBriefs: "Alpha Briefs",
    settings: "Settings",
  }
  return titles[page] || "Module"
}

function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="h-screen w-full bg-[#0a0a0f] text-white overflow-y-auto font-mono flex flex-col items-center justify-center p-8 animate-fadeIn">
      <div className="text-center max-w-md">
        <h1 className="text-4xl font-bold mb-4">{title}</h1>
        <p className="text-gray-400 text-lg">
          This module is under construction. Its intelligent features will be integrated in a future phase.
        </p>
        <div className="mt-8 text-6xl opacity-50">🚀</div>
      </div>
    </div>
  )
}
