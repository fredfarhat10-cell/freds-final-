"use client"

import FinancialCommandCenter from "@/components/financial-command-center"

export default function FinancialStudio() {
  return <FinancialCommandCenter />
}
