"use client"

import { useState, useEffect } from "react"
import { useVault } from "@/lib/vault-context"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DollarSign,
  TrendingUp,
  Target,
  Sparkles,
  Plus,
  RefreshCw,
  Zap,
  PieChart,
  FileText,
  AlertCircle,
  CheckCircle,
} from "lucide-react"
import ApexSpinner from "@/components/apex-spinner"
import {
  getUserAccounts,
  getAccountBalances,
  calculateFinancialVelocity,
  type Account,
  type BalanceSnapshot,
} from "@/lib/plaid-integration"
import {
  getBudgetSummary,
  getCashFlowInsights,
  initializeDefaultCategories,
  type BudgetSummary,
  type CashFlowInsight,
} from "@/lib/ai-cash-flow-manager"
import {
  getUserGoals,
  projectGoalCompletion,
  calculatePortfolioAllocation,
  type FinancialGoal,
  type GoalProjection,
} from "@/lib/goal-accelerator"
import { requestAlphaBrief, getUserBriefs, type AlphaBrief } from "@/lib/alpha-brief-engine"

export default function FinancialCommandCenter() {
  const { userProfile } = useVault()
  const userId = userProfile?.email || "demo-user"

  // State for accounts and balances
  const [accounts, setAccounts] = useState<Account[]>([])
  const [balances, setBalances] = useState<BalanceSnapshot[]>([])
  const [financialVelocity, setFinancialVelocity] = useState<number>(0)
  const [isLoadingAccounts, setIsLoadingAccounts] = useState(true)

  // State for budget
  const [budgetSummary, setBudgetSummary] = useState<BudgetSummary[]>([])
  const [cashFlowInsights, setCashFlowInsights] = useState<CashFlowInsight[]>([])
  const [isLoadingBudget, setIsLoadingBudget] = useState(true)

  // State for goals
  const [goals, setGoals] = useState<FinancialGoal[]>([])
  const [goalProjections, setGoalProjections] = useState<Map<string, GoalProjection>>(new Map())
  const [isLoadingGoals, setIsLoadingGoals] = useState(true)

  // State for Alpha Briefs
  const [briefs, setBriefs] = useState<AlphaBrief[]>([])
  const [selectedBrief, setSelectedBrief] = useState<AlphaBrief | null>(null)
  const [isRequestingBrief, setIsRequestingBrief] = useState(false)
  const [briefTicker, setBriefTicker] = useState("")

  // Load accounts and balances
  useEffect(() => {
    loadAccounts()
  }, [userId])

  // Load budget data
  useEffect(() => {
    loadBudgetData()
  }, [userId])

  // Load goals
  useEffect(() => {
    loadGoals()
  }, [userId])

  // Load briefs
  useEffect(() => {
    loadBriefs()
  }, [userId])

  const loadAccounts = async () => {
    setIsLoadingAccounts(true)
    try {
      const userAccounts = await getUserAccounts(userId)
      setAccounts(userAccounts)

      const accountBalances = await getAccountBalances(userId)
      setBalances(accountBalances)

      const velocity = calculateFinancialVelocity(accountBalances)
      setFinancialVelocity(velocity)
    } catch (error) {
      console.error("[v0] Error loading accounts:", error)
    } finally {
      setIsLoadingAccounts(false)
    }
  }

  const loadBudgetData = async () => {
    setIsLoadingBudget(true)
    try {
      // Initialize default categories if needed
      await initializeDefaultCategories()

      const summary = await getBudgetSummary(userId)
      setBudgetSummary(summary)

      const insights = await getCashFlowInsights(userId)
      setCashFlowInsights(insights.filter((i) => !i.isRead))
    } catch (error) {
      console.error("[v0] Error loading budget data:", error)
    } finally {
      setIsLoadingBudget(false)
    }
  }

  const loadGoals = async () => {
    setIsLoadingGoals(true)
    try {
      const userGoals = await getUserGoals(userId)
      setGoals(userGoals)

      // Load projections for each goal
      const projections = new Map<string, GoalProjection>()
      for (const goal of userGoals) {
        const projection = await projectGoalCompletion(goal)
        projections.set(goal.id, projection)
      }
      setGoalProjections(projections)
    } catch (error) {
      console.error("[v0] Error loading goals:", error)
    } finally {
      setIsLoadingGoals(false)
    }
  }

  const loadBriefs = async () => {
    try {
      const userBriefs = await getUserBriefs(userId)
      setBriefs(userBriefs)
    } catch (error) {
      console.error("[v0] Error loading briefs:", error)
    }
  }

  const handleRequestBrief = async () => {
    if (!briefTicker.trim()) return

    setIsRequestingBrief(true)
    try {
      const request = await requestAlphaBrief(userId, briefTicker)

      // Poll for completion
      if (request.status === "completed" && request.briefId) {
        await loadBriefs()
      }

      setBriefTicker("")
    } catch (error) {
      console.error("[v0] Error requesting brief:", error)
    } finally {
      setIsRequestingBrief(false)
    }
  }

  const totalBalance = balances.reduce((sum, b) => sum + b.current, 0)
  const totalAvailable = balances.reduce((sum, b) => sum + (b.available || 0), 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#001F3F] via-[#002B4F] to-[#001F3F] p-6 space-y-6">
      {/* Header */}
      <div className="animate-fadeIn">
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 flex items-center gap-3">
          <Zap className="w-10 h-10 text-cyan-400" />
          Financial Command Center
        </h1>
        <p className="text-cyan-300/60 mt-2">
          Unified balance sheet, AI cash flow management, goal acceleration, and investment research
        </p>
      </div>

      {/* Financial Velocity Dashboard */}
      <Card className="bg-black/40 backdrop-blur-md border border-cyan-500/30 p-6 hover:border-cyan-500/50 transition-all animate-fadeIn">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-cyan-400" />
            Financial Velocity
          </h2>
          <Button
            onClick={loadAccounts}
            disabled={isLoadingAccounts}
            variant="outline"
            className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 bg-transparent"
          >
            {isLoadingAccounts ? <ApexSpinner size={16} /> : <RefreshCw className="w-4 h-4" />}
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-lg p-4">
            <p className="text-cyan-300/60 text-sm">Total Balance</p>
            <p className="text-3xl font-bold text-white">${totalBalance.toLocaleString()}</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg p-4">
            <p className="text-green-300/60 text-sm">Available</p>
            <p className="text-3xl font-bold text-white">${totalAvailable.toLocaleString()}</p>
          </div>

          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-lg p-4">
            <p className="text-purple-300/60 text-sm">Accounts</p>
            <p className="text-3xl font-bold text-white">{accounts.length}</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-lg p-4">
            <p className="text-orange-300/60 text-sm">Velocity</p>
            <p className={`text-3xl font-bold ${financialVelocity >= 0 ? "text-green-400" : "text-red-400"}`}>
              {financialVelocity >= 0 ? "+" : ""}
              {financialVelocity.toFixed(1)}%
            </p>
          </div>
        </div>

        {accounts.length > 0 && (
          <div className="mt-6 space-y-2">
            <h3 className="text-sm font-semibold text-cyan-300/80 mb-3">Connected Accounts</h3>
            {accounts.map((account) => (
              <div
                key={account.id}
                className="flex items-center justify-between p-3 bg-black/30 rounded-lg border border-cyan-500/10"
              >
                <div>
                  <p className="font-medium text-white">{account.name}</p>
                  <p className="text-xs text-gray-400">{account.type}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-white">${account.balance.toLocaleString()}</p>
                  <p className="text-xs text-gray-400">{account.institution}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Tabs for different sections */}
      <Tabs defaultValue="budget" className="w-full">
        <TabsList className="bg-black/40 border border-cyan-500/30">
          <TabsTrigger value="budget" className="data-[state=active]:bg-cyan-500/20">
            <PieChart className="w-4 h-4 mr-2" />
            Cash Flow
          </TabsTrigger>
          <TabsTrigger value="goals" className="data-[state=active]:bg-cyan-500/20">
            <Target className="w-4 h-4 mr-2" />
            Goals
          </TabsTrigger>
          <TabsTrigger value="research" className="data-[state=active]:bg-cyan-500/20">
            <FileText className="w-4 h-4 mr-2" />
            Alpha Briefs
          </TabsTrigger>
        </TabsList>

        {/* Budget & Cash Flow Tab */}
        <TabsContent value="budget" className="space-y-6 mt-6">
          {/* Cash Flow Insights */}
          {cashFlowInsights.length > 0 && (
            <Card className="bg-black/40 backdrop-blur-md border border-cyan-500/30 p-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-4">
                <AlertCircle className="w-6 h-6 text-yellow-400" />
                Cash Flow Insights
              </h2>
              <div className="space-y-3">
                {cashFlowInsights.map((insight) => (
                  <div
                    key={insight.id}
                    className={`p-4 rounded-lg border ${
                      insight.type === "alert"
                        ? "bg-red-500/10 border-red-500/30"
                        : insight.type === "warning"
                          ? "bg-yellow-500/10 border-yellow-500/30"
                          : "bg-blue-500/10 border-blue-500/30"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-white">{insight.title}</h3>
                        <p className="text-sm text-gray-300 mt-1">{insight.description}</p>
                        {insight.actionable && insight.action && (
                          <p className="text-xs text-cyan-400 mt-2">{insight.action}</p>
                        )}
                      </div>
                      <span
                        className={`text-xs px-2 py-1 rounded ${
                          insight.priority === "high"
                            ? "bg-red-500/20 text-red-300"
                            : insight.priority === "medium"
                              ? "bg-yellow-500/20 text-yellow-300"
                              : "bg-blue-500/20 text-blue-300"
                        }`}
                      >
                        {insight.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Budget Summary */}
          <Card className="bg-black/40 backdrop-blur-md border border-cyan-500/30 p-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-4">
              <PieChart className="w-6 h-6 text-cyan-400" />
              Budget Overview
            </h2>

            {isLoadingBudget ? (
              <div className="flex items-center justify-center py-8">
                <ApexSpinner size={32} />
              </div>
            ) : budgetSummary.length > 0 ? (
              <div className="space-y-3">
                {budgetSummary.map((category) => (
                  <div key={category.categoryId} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-white font-medium">{category.categoryName}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-400">
                          ${category.spent.toFixed(0)} / ${category.allocated.toFixed(0)}
                        </span>
                        {category.status === "healthy" && <CheckCircle className="w-4 h-4 text-green-400" />}
                        {category.status === "warning" && <AlertCircle className="w-4 h-4 text-yellow-400" />}
                        {category.status === "overspent" && <AlertCircle className="w-4 h-4 text-red-400" />}
                      </div>
                    </div>
                    <div className="w-full bg-gray-700/30 rounded-full h-2">
                      <div
                        className={`h-full rounded-full transition-all ${
                          category.status === "healthy"
                            ? "bg-green-500"
                            : category.status === "warning"
                              ? "bg-yellow-500"
                              : "bg-red-500"
                        }`}
                        style={{ width: `${Math.min(category.percentUsed, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-cyan-300/40 text-center py-8">
                No budget data available. Start tracking your spending to see insights.
              </p>
            )}
          </Card>
        </TabsContent>

        {/* Goals Tab */}
        <TabsContent value="goals" className="space-y-6 mt-6">
          <Card className="bg-black/40 backdrop-blur-md border border-cyan-500/30 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <Target className="w-6 h-6 text-cyan-400" />
                Financial Goals
              </h2>
              <Button className="bg-cyan-500 hover:bg-cyan-600">
                <Plus className="w-4 h-4 mr-2" />
                Add Goal
              </Button>
            </div>

            {isLoadingGoals ? (
              <div className="flex items-center justify-center py-8">
                <ApexSpinner size={32} />
              </div>
            ) : goals.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {goals.map((goal) => {
                  const projection = goalProjections.get(goal.id)
                  const progress = (goal.currentAmount / goal.targetAmount) * 100
                  const allocation = calculatePortfolioAllocation(goal)

                  return (
                    <div
                      key={goal.id}
                      className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-lg p-4"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-bold text-white">{goal.name}</h3>
                          <p className="text-xs text-gray-400">{goal.type}</p>
                        </div>
                        <span
                          className={`text-xs px-2 py-1 rounded ${
                            goal.status === "ahead"
                              ? "bg-green-500/20 text-green-300"
                              : goal.status === "on-track"
                                ? "bg-blue-500/20 text-blue-300"
                                : goal.status === "behind"
                                  ? "bg-yellow-500/20 text-yellow-300"
                                  : "bg-gray-500/20 text-gray-300"
                          }`}
                        >
                          {goal.status}
                        </span>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-cyan-300/60">Progress</span>
                          <span className="text-white font-semibold">{progress.toFixed(1)}%</span>
                        </div>

                        <div className="w-full bg-cyan-900/30 rounded-full h-3">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all"
                            style={{ width: `${Math.min(progress, 100)}%` }}
                          />
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-cyan-300/60">
                            ${goal.currentAmount.toLocaleString()} / ${goal.targetAmount.toLocaleString()}
                          </span>
                          <span className="text-cyan-300/60">{new Date(goal.targetDate).toLocaleDateString()}</span>
                        </div>

                        {projection && (
                          <div className="mt-3 pt-3 border-t border-cyan-500/20 space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className="text-gray-400">Success Probability</span>
                              <span className="text-white font-semibold">
                                {projection.probabilityOfSuccess.toFixed(0)}%
                              </span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span className="text-gray-400">Expected Return</span>
                              <span className="text-white font-semibold">{allocation.expectedReturn.toFixed(1)}%</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span className="text-gray-400">Risk Level</span>
                              <span className="text-white font-semibold">{goal.riskTolerance}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-cyan-300/40 text-center py-8">
                No goals set. Create your first financial goal to start tracking progress.
              </p>
            )}
          </Card>
        </TabsContent>

        {/* Alpha Briefs Tab */}
        <TabsContent value="research" className="space-y-6 mt-6">
          <Card className="bg-black/40 backdrop-blur-md border border-cyan-500/30 p-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse" />
              Alpha Brief Research Engine
            </h2>
            <p className="text-cyan-300/60 text-sm mb-6">
              Get AI-powered investment research in 60 seconds. Enter any ticker symbol to generate a comprehensive
              analysis.
            </p>

            <div className="flex gap-2 mb-6">
              <input
                type="text"
                value={briefTicker}
                onChange={(e) => setBriefTicker(e.target.value.toUpperCase())}
                placeholder="Enter ticker (e.g., AAPL, TSLA)"
                className="flex-1 bg-cyan-900/20 border border-cyan-500/30 rounded-md px-4 py-2 text-white focus:outline-none focus:border-cyan-500/50 uppercase"
                onKeyDown={(e) => e.key === "Enter" && handleRequestBrief()}
              />
              <Button
                onClick={handleRequestBrief}
                disabled={isRequestingBrief || !briefTicker.trim()}
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
              >
                {isRequestingBrief ? (
                  <>
                    <ApexSpinner size={16} />
                    <span className="ml-2">Generating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Brief
                  </>
                )}
              </Button>
            </div>

            {briefs.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-cyan-300/80">Recent Briefs</h3>
                {briefs.map((brief) => (
                  <button
                    key={brief.id}
                    onClick={() => setSelectedBrief(brief)}
                    className="w-full text-left p-4 bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/20 rounded-lg hover:border-purple-500/40 transition-all"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="font-bold text-white">{brief.ticker}</h4>
                        <p className="text-sm text-gray-400">{brief.companyName}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-cyan-400">{brief.sections.recommendation.rating.toUpperCase()}</p>
                        <p className="text-xs text-gray-400">{new Date(brief.generatedAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-400">
                      <span>Target: ${brief.sections.recommendation.targetPrice}</span>
                      <span>Confidence: {brief.sections.recommendation.confidence}%</span>
                      <span>Sentiment: {brief.sections.news.overallSentiment}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </Card>

          {/* Brief Detail Modal */}
          {selectedBrief && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn overflow-y-auto">
              <div className="bg-gradient-to-br from-[#001F3F] to-[#002B4F] border border-cyan-500/50 rounded-lg p-6 max-w-4xl w-full my-8">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h2 className="text-3xl font-bold text-white">{selectedBrief.ticker}</h2>
                    <p className="text-cyan-300/60">{selectedBrief.companyName}</p>
                  </div>
                  <button
                    onClick={() => setSelectedBrief(null)}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-6">
                  {/* Recommendation */}
                  <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/20 rounded-lg p-4">
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <Target className="w-5 h-5 text-purple-400" />
                      Investment Recommendation
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-400">Rating</p>
                        <p className="text-lg font-bold text-white">
                          {selectedBrief.sections.recommendation.rating.toUpperCase()}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Target Price</p>
                        <p className="text-lg font-bold text-white">
                          ${selectedBrief.sections.recommendation.targetPrice}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Confidence</p>
                        <p className="text-lg font-bold text-white">
                          {selectedBrief.sections.recommendation.confidence}%
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Time Horizon</p>
                        <p className="text-lg font-bold text-white">
                          {selectedBrief.sections.recommendation.timeHorizon}
                        </p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300">{selectedBrief.sections.recommendation.allocation}</p>
                  </div>

                  {/* Financials */}
                  <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-lg p-4">
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-cyan-400" />
                      Key Financials
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-gray-400">Current Price</p>
                        <p className="text-lg font-bold text-white">
                          ${selectedBrief.sections.financials.currentPrice}
                        </p>
                        <p
                          className={`text-xs ${selectedBrief.sections.financials.priceChangePercent24h >= 0 ? "text-green-400" : "text-red-400"}`}
                        >
                          {selectedBrief.sections.financials.priceChangePercent24h >= 0 ? "+" : ""}
                          {selectedBrief.sections.financials.priceChangePercent24h.toFixed(2)}%
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">P/E Ratio</p>
                        <p className="text-lg font-bold text-white">{selectedBrief.sections.financials.peRatio}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Market Cap</p>
                        <p className="text-lg font-bold text-white">
                          ${(selectedBrief.sections.financials.marketCap / 1e9).toFixed(1)}B
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Revenue Growth</p>
                        <p className="text-lg font-bold text-white">
                          {selectedBrief.sections.financials.revenueGrowth.toFixed(1)}%
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* News Sentiment */}
                  <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg p-4">
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-green-400" />
                      News & Sentiment
                    </h3>
                    <div className="flex items-center gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-400">Overall Sentiment</p>
                        <p className="text-lg font-bold text-white">
                          {selectedBrief.sections.news.overallSentiment.toUpperCase()}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Sentiment Score</p>
                        <p className="text-lg font-bold text-white">{selectedBrief.sections.news.sentimentScore}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {selectedBrief.sections.news.recentNews.slice(0, 3).map((news, idx) => (
                        <div key={idx} className="text-sm">
                          <p className="text-white font-medium">{news.title}</p>
                          <p className="text-xs text-gray-400">
                            {news.source} • {new Date(news.publishedAt).toLocaleDateString()}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Risk Assessment */}
                  <div className="bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-red-500/20 rounded-lg p-4">
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-red-400" />
                      Risk Assessment
                    </h3>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-400">Overall Risk</p>
                        <p className="text-lg font-bold text-white">
                          {selectedBrief.sections.risks.overallRisk.toUpperCase()}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Risk Score</p>
                        <p className="text-lg font-bold text-white">{selectedBrief.sections.risks.riskScore}/100</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {selectedBrief.sections.risks.factors.map((factor, idx) => (
                        <div key={idx} className="text-sm">
                          <p className="text-white font-medium">{factor.category}</p>
                          <p className="text-xs text-gray-400">{factor.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
