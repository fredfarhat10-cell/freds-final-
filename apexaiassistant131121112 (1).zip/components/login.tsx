"use client"

import type React from "react"

import { useState } from "react"
import { useVault } from "@/lib/vault-context"
import Spinner from "./spinner"
import { LockIcon, ShieldCheckIcon } from "./icons"

export default function Login() {
  const { login } = useVault()
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [isUnlocking, setIsUnlocking] = useState(false)
  const [attempts, setAttempts] = useState(0)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    console.log("[v0] Login attempt started")
    const success = await login(password)
    console.log("[v0] Login result:", success)

    if (!success) {
      const newAttempts = attempts + 1
      setAttempts(newAttempts)

      if (newAttempts >= 3) {
        setError(
          "Multiple failed attempts detected. Incorrect password or corrupted vault data. Your data remains encrypted and secure.",
        )
      } else {
        setError(`Incorrect password—data locked. ${3 - newAttempts} attempt(s) remaining before security warning.`)
      }
      setIsLoading(false)
    } else {
      setIsUnlocking(true)
      console.log("[v0] Vault unlocked successfully")
    }
  }

  return (
    <div className="min-h-screen bg-apex-darker flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
      <div className="absolute inset-0 bg-gradient-radial from-apex-primary/5 via-transparent to-transparent"></div>

      {isUnlocking && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-apex-darker animate-fade-in">
          <div className="text-center space-y-4">
            <div className="relative">
              <ShieldCheckIcon className="w-24 h-24 text-apex-primary mx-auto animate-pulse-glow" />
              <div className="absolute inset-0 bg-apex-primary/20 blur-3xl animate-pulse"></div>
            </div>
            <p className="text-xl font-semibold text-apex-primary animate-pulse">Vault Unlocked</p>
            <p className="text-sm text-apex-gray">Decrypting your data...</p>
          </div>
        </div>
      )}

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8 space-y-4">
          <div className="relative inline-block">
            <LockIcon className="w-20 h-20 text-apex-primary mx-auto animate-float" />
            <div className="absolute inset-0 bg-apex-primary/20 blur-2xl animate-pulse"></div>
          </div>
          <div>
            <h1 className="text-4xl font-bold text-white mb-2 animate-fade-in">Apex Vault</h1>
            <p className="text-apex-gray animate-fade-in animation-delay-100">
              Zero-knowledge encryption • Local-first AI
            </p>
          </div>
        </div>

        <div className="bg-apex-dark/80 backdrop-blur-xl p-8 rounded-2xl border border-gray-800/50 shadow-2xl animate-slide-up">
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="text-sm font-medium text-apex-gray block mb-2">Master Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoFocus
                placeholder="Enter your password"
                className="w-full bg-apex-darker/50 border border-gray-700 rounded-lg p-3 outline-none focus:ring-2 focus:ring-apex-primary focus:border-transparent text-white transition-all"
              />
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 animate-shake">
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-apex-primary to-apex-accent text-white font-semibold py-3 rounded-lg hover:shadow-lg hover:shadow-apex-primary/50 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              {isLoading ? (
                <>
                  <Spinner />
                  <span>Decrypting...</span>
                </>
              ) : (
                <>
                  <ShieldCheckIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span>Unlock Vault</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-800">
            <div className="flex items-center justify-center gap-2 text-xs text-apex-gray">
              <ShieldCheckIcon className="w-4 h-4" />
              <span>AES-256-GCM Encryption • PBKDF2 (100k iterations)</span>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-3 gap-4 text-center">
          <div className="space-y-1">
            <div className="text-2xl">🔒</div>
            <p className="text-xs text-apex-gray">Zero-Knowledge</p>
          </div>
          <div className="space-y-1">
            <div className="text-2xl">💻</div>
            <p className="text-xs text-apex-gray">Local-First</p>
          </div>
          <div className="space-y-1">
            <div className="text-2xl">🚫</div>
            <p className="text-xs text-apex-gray">No Cloud</p>
          </div>
        </div>
      </div>
    </div>
  )
}
