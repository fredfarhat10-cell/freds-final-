"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Analytics } from "@/lib/analytics"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { TrendingUp, Clock, Target, Download, Trash2 } from "lucide-react"

export default function AnalyticsDashboard() {
  const [summary, setSummary] = useState<ReturnType<typeof Analytics.getSummary> | null>(null)
  const [dailyPattern, setDailyPattern] = useState<ReturnType<typeof Analytics.getDailyActivePattern>>([])

  useEffect(() => {
    refreshData()
  }, [])

  const refreshData = () => {
    setSummary(Analytics.getSummary())
    setDailyPattern(Analytics.getDailyActivePattern())
  }

  const handleExport = () => {
    const data = Analytics.export()
    const blob = new Blob([data], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `apex-analytics-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const handleClear = () => {
    if (confirm("Are you sure you want to clear all analytics data? This cannot be undone.")) {
      Analytics.clear()
      refreshData()
    }
  }

  if (!summary) return null

  const COLORS = ["#22d3ee", "#06b6d4", "#67e8f9", "#a78bfa", "#94a3b8"]

  const featureData = summary.topFeatures.map((f) => ({
    name: f.feature,
    value: f.count,
  }))

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000)
    if (minutes < 60) return `${minutes}m`
    const hours = Math.floor(minutes / 60)
    const remainingMinutes = minutes % 60
    return `${hours}h ${remainingMinutes}m`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Usage Analytics</h2>
          <p className="text-apex-gray text-sm">All data is stored locally and never leaves your device</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleExport} variant="outline" size="sm" className="bg-transparent">
            <Download size={16} className="mr-2" />
            Export
          </Button>
          <Button onClick={handleClear} variant="outline" size="sm" className="bg-transparent text-red-400">
            <Trash2 size={16} className="mr-2" />
            Clear
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-apex-dark border-gray-800 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-apex-primary/20 rounded-lg">
              <Target className="text-apex-primary" size={24} />
            </div>
            <div>
              <p className="text-sm text-apex-gray">Completion Rate</p>
              <p className="text-2xl font-bold text-white">{summary.completionRate}%</p>
            </div>
          </div>
        </Card>

        <Card className="bg-apex-dark border-gray-800 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-apex-accent/20 rounded-lg">
              <TrendingUp className="text-apex-accent" size={24} />
            </div>
            <div>
              <p className="text-sm text-apex-gray">Total Sessions</p>
              <p className="text-2xl font-bold text-white">{summary.sessionCount}</p>
            </div>
          </div>
        </Card>

        <Card className="bg-apex-dark border-gray-800 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <Clock className="text-purple-400" size={24} />
            </div>
            <div>
              <p className="text-sm text-apex-gray">Avg Session</p>
              <p className="text-2xl font-bold text-white">{formatTime(summary.avgSessionTime)}</p>
            </div>
          </div>
        </Card>

        <Card className="bg-apex-dark border-gray-800 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-500/20 rounded-lg">
              <TrendingUp className="text-green-400" size={24} />
            </div>
            <div>
              <p className="text-sm text-apex-gray">Recent Events</p>
              <p className="text-2xl font-bold text-white">{summary.recentEvents}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-apex-dark border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Daily Activity (Last 30 Days)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={dailyPattern}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#94a3b8" tick={{ fontSize: 12 }} />
              <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} />
              <Tooltip
                contentStyle={{ backgroundColor: "#0f1419", border: "1px solid #374151", borderRadius: "8px" }}
                labelStyle={{ color: "#f1f5f9" }}
              />
              <Bar dataKey="events" fill="#22d3ee" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="bg-apex-dark border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Top Features Used</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={featureData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {featureData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: "#0f1419", border: "1px solid #374151", borderRadius: "8px" }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card className="bg-apex-dark border-gray-800 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Feature Usage Details</h3>
        <div className="space-y-3">
          {summary.topFeatures.map((feature, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-apex-darker rounded-lg">
              <div>
                <p className="text-white font-medium">{feature.feature}</p>
                <p className="text-xs text-apex-gray">Last used: {new Date(feature.lastUsed).toLocaleDateString()}</p>
              </div>
              <div className="text-right">
                <p className="text-apex-accent font-bold">{feature.count}</p>
                <p className="text-xs text-apex-gray">uses</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
