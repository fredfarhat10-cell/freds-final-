"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useVault } from "@/lib/vault-context"
import type { UserProfile } from "@/lib/types"
import { ShieldCheckIcon } from "@heroicons/react/24/solid"
import Spinner from "./spinner"

interface ConversationalOnboardingProps {
  onComplete?: () => void
}

export default function ConversationalOnboarding({ onComplete }: ConversationalOnboardingProps) {
  const { createVault } = useVault()
  const [phase, setPhase] = useState("orb") // orb | security
  const [stage, setStage] = useState("intro")
  const [messages, setMessages] = useState<Array<{ from: "apex" | "user"; text: string }>>([])
  const [userInfo, setUserInfo] = useState<Partial<UserProfile>>({})
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const orbRef = useRef<HTMLDivElement>(null)

  // Adaptive greeting logic
  const getAdaptiveGreeting = (prefs: Partial<UserProfile>) => {
    let greet = "Hello there"
    const country = prefs.location?.toLowerCase() || ""
    const interests = prefs.interests?.join(" ").toLowerCase() || ""

    if (country.includes("italy")) greet = "Ciao"
    else if (country.includes("india") || interests.includes("wellness")) greet = "Namaste"
    else if (country.includes("france")) greet = "Bonjour"
    else if (country.includes("japan")) greet = "Konnichiwa"
    else if (country.includes("spain")) greet = "Hola"

    return greet
  }

  useEffect(() => {
    // Start the conversation like Jarvis
    setTimeout(() => {
      addApex("Allow me to introduce myself — I'm Apex, your adaptive AI companion.")
      setTimeout(() => {
        addApex("I learn through conversation, observation, and emotion — never through forms.")
        setTimeout(() => {
          addApex("Here are a few things you can ask me:")
          setTimeout(() => {
            addApex("• 'Help me rebalance my investments'")
            addApex("• 'Design a healthier daily routine'")
            addApex("• 'Explain what's affecting my portfolio'")
            addApex("• 'Track my goals for the month'")
            setTimeout(() => {
              addApex("Before we start, what's your name?")
              setStage("askName")
            }, 2000)
          }, 1000)
        }, 1500)
      }, 1000)
    }, 1000)
  }, [])

  function addApex(text: string) {
    setMessages((m) => [...m, { from: "apex", text }])
  }

  function addUser(text: string) {
    setMessages((m) => [...m, { from: "user", text }])
  }

  function handleUserResponse(text: string) {
    if (stage === "askName") {
      const name = text.split(" ")[0]
      const prefs = { ...userInfo, name }
      addUser(text)
      addApex(`Nice to meet you, ${name}. Where are you from?`)
      setStage("askLocation")
      setUserInfo(prefs)
    } else if (stage === "askLocation") {
      const location = text.trim()
      const prefs = { ...userInfo, location }
      addUser(text)
      addApex(
        `${getAdaptiveGreeting(prefs)}, ${prefs.name}. What's something that motivates or interests you most right now?`,
      )
      setStage("askInterest")
      setUserInfo(prefs)
    } else if (stage === "askInterest") {
      const interest = text.trim()
      const prefs = { ...userInfo, interests: [interest] }
      addUser(text)
      const greet = getAdaptiveGreeting(prefs)
      addApex(
        `${greet}, ${prefs.name}. You seem passionate about ${interest}. Now let's secure your data with a master password.`,
      )
      setTimeout(() => setPhase("security"), 2500)
    }
  }

  const handleCreateVault = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      setError("Passwords do not match.")
      return
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters long.")
      return
    }
    setError("")
    setIsLoading(true)

    // Create a complete user profile with defaults
    const completeProfile: UserProfile = {
      name: userInfo.name || "User",
      occupation: "Not specified",
      location: userInfo.location || "Not specified",
      skills: [],
      interests: userInfo.interests || [],
      hobbies: [],
      financialRiskStyle: "Moderate",
      aiPersona: "Collaborator",
      aiModel: "GPT-4",
    }

    await createVault(completeProfile, password, true)

    if (onComplete) {
      onComplete()
    }
  }

  if (phase === "orb") {
    return (
      <section className="flex flex-col items-center justify-between min-h-screen text-white px-4 py-6 bg-gradient-to-br from-apex-darker via-apex-dark to-apex-darker">
        {/* Orb visual */}
        <div className="flex flex-col items-center mb-6 flex-1 justify-center max-w-3xl w-full">
          <div
            ref={orbRef}
            className="w-36 h-36 rounded-full bg-gradient-to-r from-apex-secondary via-apex-primary to-apex-accent mb-8 shadow-lg shadow-apex-primary/30 animate-pulse transition-all"
          />

          {/* Conversation display */}
          <div className="overflow-y-auto max-h-[50vh] w-full space-y-3 mb-8">
            {messages.map((m, i) => (
              <div key={i} className={`animate-fadeIn ${m.from === "apex" ? "text-left" : "text-right"}`}>
                <div
                  className={`inline-block max-w-[80%] px-4 py-3 rounded-2xl ${
                    m.from === "apex"
                      ? "bg-apex-primary/10 border border-apex-primary/30 text-apex-light"
                      : "bg-apex-accent/20 border border-apex-accent/30 text-white font-medium"
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* User input */}
        <form
          onSubmit={(e) => {
            e.preventDefault()
            const text = e.target.elements.input.value.trim()
            if (!text) return
            handleUserResponse(text)
            e.target.reset()
          }}
          className="flex items-center w-full max-w-2xl gap-3 pb-6"
        >
          <input
            name="input"
            placeholder="Say something to Apex..."
            className="flex-1 px-5 py-4 rounded-xl bg-white/10 border border-apex-primary/30 text-white placeholder-gray-400 outline-none focus:ring-2 focus:ring-apex-primary transition-all"
            autoFocus
          />
          <button
            type="submit"
            className="px-6 py-4 rounded-xl bg-gradient-to-r from-apex-primary to-apex-accent font-semibold hover:scale-105 transition-all shadow-lg shadow-apex-primary/20"
          >
            Send
          </button>
        </form>
      </section>
    )
  }

  // Security phase
  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4 bg-gradient-to-br from-apex-darker via-apex-dark to-apex-darker">
      <div className="relative z-10 w-full max-w-md glass-effect p-8 rounded-2xl animate-fadeIn">
        <div className="flex items-center justify-center mb-6">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-apex-primary to-apex-accent animate-glow flex items-center justify-center">
            <ShieldCheckIcon className="w-8 h-8 text-white" />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-center mb-2 gradient-text">Seal Your Nexus</h1>
        <p className="text-center text-apex-gray mb-6 text-sm">Create your master encryption key</p>

        <form onSubmit={handleCreateVault} className="space-y-4">
          <div className="bg-green-500/10 border border-green-500/30 p-4 rounded-lg mb-4 space-y-2">
            <div className="flex items-center justify-center gap-2">
              <ShieldCheckIcon className="w-5 h-5 text-green-400" />
              <p className="font-semibold text-green-400">Zero-Knowledge Encryption</p>
            </div>
            <p className="text-xs text-apex-gray leading-relaxed text-center">
              Your master password encrypts all data locally using AES-256-GCM. It is NEVER sent to any server. If you
              forget it, your data cannot be recovered.
            </p>
          </div>

          <div>
            <label className="text-sm font-medium text-apex-light">Master Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Minimum 8 characters"
              className="w-full bg-black/50 border border-apex-primary/30 rounded-lg p-3 mt-1 outline-none focus:ring-2 focus:ring-apex-primary text-white transition-all"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-apex-light">Confirm Password</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              className="w-full bg-black/50 border border-apex-primary/30 rounded-lg p-3 mt-1 outline-none focus:ring-2 focus:ring-apex-primary text-white transition-all"
            />
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 p-3 rounded-lg">
              <p className="text-red-400 text-sm text-center">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-apex-primary to-apex-secondary text-white font-semibold py-3 rounded-lg hover:shadow-[0_0_20px_rgba(0,255,255,0.5)] transition-all duration-300 hover:scale-[1.02] flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? <Spinner /> : "Activate Symbiosis"}
          </button>
        </form>
      </div>
    </div>
  )
}
