"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plug, CheckCircle, XCircle, RefreshCw, Calendar, DollarSign, Activity } from "lucide-react"
import {
  getAllIntegrations,
  getIntegrationStats,
  disconnectIntegration,
  getAvailableProviders,
} from "@/lib/integration-manager"
import type { Integration, IntegrationProvider, IntegrationStats } from "@/lib/types/integration"

export function IntegrationHub() {
  const [integrations, setIntegrations] = useState<Integration[]>([])
  const [providers, setProviders] = useState<IntegrationProvider[]>([])
  const [stats, setStats] = useState<IntegrationStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setIsLoading(true)
    try {
      const [allIntegrations, availableProviders, integrationStats] = await Promise.all([
        getAllIntegrations(),
        getAvailableProviders(),
        getIntegrationStats(),
      ])

      setIntegrations(allIntegrations)
      setProviders(availableProviders)
      setStats(integrationStats)
    } catch (error) {
      console.error("[v0] Failed to load integrations:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDisconnect = async (integrationId: string) => {
    if (!confirm("Are you sure you want to disconnect this integration?")) return

    await disconnectIntegration(integrationId)
    await loadData()
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "calendar":
        return <Calendar className="h-4 w-4" />
      case "bank":
        return <DollarSign className="h-4 w-4" />
      case "health":
      case "fitness":
        return <Activity className="h-4 w-4" />
      default:
        return <Plug className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "bg-green-500/20 text-green-400 border-green-500/50"
      case "error":
        return "bg-red-500/20 text-red-400 border-red-500/50"
      case "pending":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/50"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plug className="h-5 w-5" />
            Integration Hub
          </CardTitle>
          <CardDescription>Manage all your third-party service connections</CardDescription>
        </CardHeader>
        <CardContent>
          {stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Connected</p>
                <p className="text-2xl font-bold">{stats.totalConnected}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Calendar</p>
                <p className="text-2xl font-bold">{stats.byType.calendar}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Financial</p>
                <p className="text-2xl font-bold">{stats.byType.bank}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Health/Fitness</p>
                <p className="text-2xl font-bold">{stats.byType.health + stats.byType.fitness}</p>
              </div>
            </div>
          )}

          <Tabs defaultValue="connected" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="connected">Connected</TabsTrigger>
              <TabsTrigger value="available">Available</TabsTrigger>
            </TabsList>

            <TabsContent value="connected" className="space-y-3">
              {isLoading ? (
                <p className="text-center text-muted-foreground py-8">Loading integrations...</p>
              ) : integrations.filter((i) => i.status === "connected").length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No integrations connected yet</p>
              ) : (
                integrations
                  .filter((i) => i.status === "connected")
                  .map((integration) => (
                    <Card key={integration.id}>
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex gap-3 items-start">
                            <div className="p-2 bg-primary/10 rounded-lg">{getTypeIcon(integration.type)}</div>
                            <div>
                              <h3 className="font-semibold">{integration.name}</h3>
                              <p className="text-sm text-muted-foreground">{integration.description}</p>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge className={getStatusColor(integration.status)}>{integration.status}</Badge>
                          <Badge variant="secondary">{integration.type}</Badge>
                          {integration.lastSyncedAt && (
                            <Badge variant="outline">
                              <RefreshCw className="h-3 w-3 mr-1" />
                              Synced {new Date(integration.lastSyncedAt).toLocaleDateString()}
                            </Badge>
                          )}
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => handleDisconnect(integration.id)}>
                            <XCircle className="h-4 w-4 mr-2" />
                            Disconnect
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              )}
            </TabsContent>

            <TabsContent value="available" className="space-y-3">
              {providers.map((provider) => (
                <Card key={provider.id}>
                  <CardContent className="pt-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex gap-3 items-start">
                        <div className="p-2 bg-primary/10 rounded-lg">{getTypeIcon(provider.type)}</div>
                        <div>
                          <h3 className="font-semibold">{provider.name}</h3>
                          <p className="text-sm text-muted-foreground">{provider.description}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="secondary">{provider.type}</Badge>
                      {provider.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <Button size="sm" disabled={provider.requiresSetup}>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      {provider.requiresSetup ? "Setup Required" : "Connect"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
